
Line Chart
""""""""""

.. lv_example:: widgets/chart/lv_example_chart_1
  :language: c


Faded area line chart with custom division lines
"""""""""""""""""""""""""""""""""""""""""""""""""""

.. lv_example:: widgets/chart/lv_example_chart_2
  :language: c

Axis ticks and labels with scrolling
""""""""""""""""""""""""""""""""""""

.. lv_example:: widgets/chart/lv_example_chart_3
  :language: c

Show the value of the pressed points
""""""""""""""""""""""""""""""""""""""

.. lv_example:: widgets/chart/lv_example_chart_4
  :language: c

Display 1000 data points with zooming and scrolling
""""""""""""""""""""""""""""""""""""""""""""""""""""

.. lv_example:: widgets/chart/lv_example_chart_5
  :language: c

Show cursor on the clicked point
"""""""""""""""""""""""""""""""""""

.. lv_example:: widgets/chart/lv_example_chart_6
  :language: c

Scatter chart
"""""""""""""""""""""""""""""""""""

.. lv_example:: widgets/chart/lv_example_chart_7
  :language: c

Stacked area chart
"""""""""""""""""""""""""""""""""""

.. lv_example:: widgets/chart/lv_example_chart_8
  :language:
